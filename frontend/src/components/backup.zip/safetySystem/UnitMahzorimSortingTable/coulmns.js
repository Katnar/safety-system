import { ColumnFilter } from './ColumnFilter'
export const COLUMNS = [
    {
        Header: 'שם מחזור',
        accessor: 'name',
        Filter: ColumnFilter
    },
]